module.exports = {
  trailingComma: "all",
  tabWidth: 2,
  singleQuote: false,
  formatOnSave: true,
  formatOnPaste: true,
  htmlWhitespaceSensitivity: "ignore",
};
