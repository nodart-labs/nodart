module.exports = {
  trailingComma: "all",
  tabWidth: 2,
  singleQuote: false,
  htmlWhitespaceSensitivity: "ignore",
};
