import {Controller, HttpException} from "nodart";
import {SampleModel} from "../models/sample";
import {SampleService} from "../services/sample";

export class SampleController extends Controller {

    model = {
        sample: {} as SampleModel
    }

    service = {
        sample: {} as SampleService
    }

    async init() {
    }

    get(): any {
        this.send.view('index', {
            title: 'Sample',
            message: `This page has been parsed by template engine. See Docs: 
            <a href="https://mozilla.github.io/nunjucks/api.html" target="_blank">https://mozilla.github.io/nunjucks/api.html</a>`
        })
    }

    head(): any {
    }

    patch(): any {
    }

    post(): any {
    }

    put(): any {
    }

    delete(): any {
    }
}
