import {Model} from "nodart";

export class SampleModel extends Model {

}
