import {nodart} from "nodart";

export = <nodart.router.RouteEntry>{}
