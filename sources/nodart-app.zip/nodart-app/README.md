## NODART FRAMEWORK APPLICATION

---

### RUN UNDER DEVELOPMENT SERVER
```
npm run dev
```

### RUN UNDER PRODUCTION
```
npm run start
```

---

### COMMAND LINE INTERFACE

### System Commands:
```
npx nodart [command name] [command action (optional)] --[argument name (optional)] [argument value]
```

### App Commands:
```
node cmd [command name] [command action (optional)] --[argument name (optional)] [argument value]
```

---

### Create App:
```
npx nodart create-app
```
