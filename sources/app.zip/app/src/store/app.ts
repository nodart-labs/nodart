export = Object.freeze({
    states: {},
    events: {},
    listeners: []
})
