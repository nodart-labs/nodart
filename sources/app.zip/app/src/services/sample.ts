import {Service} from "nodart";
import {SampleController} from "../controllers/sample_controller";

export class SampleService extends Service {

    get controller() {

        return this.scope.controller() as SampleController
    }

    get orm() {

        return this.scope.app.service.db.orm // or this.scope.app.get('orm').call() as Orm
    }

}
